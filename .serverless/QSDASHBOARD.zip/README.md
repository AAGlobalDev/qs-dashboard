# qsDashboard
AWS Quicksight, RDS, Lambda Function by Python
